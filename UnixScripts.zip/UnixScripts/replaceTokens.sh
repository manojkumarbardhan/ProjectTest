#!/bin/bash

echo -e "\n******* Starting program ******* \n"


inputfile=$1
propfile=$2
outputfile=$3

#Validating the input params.
extension=$(echo ${inputfile}|awk -F\. '{print $2}')
if [ $# -ne 3 ]
then
	echo "error: insufficient input for $0" 
    	echo "You need 3 parameters 1.Input HTML 2.Input Properties 3.Output HTML !! Please provide valid inputs."
    	exit 1
elif [ ${extension} !=  "html" ]
then
   	echo "Error: Input file must be an HTML file.Please provide valid input."
	exit 1
fi

inputfile=$1
propfile=$2
outputfile=$3

echo "Input HTML is :" $inputfile
echo "Input Properties is :"$propfile
echo -e "Output html file is: $outputfile \n"

echo "Checking for existing output files ??"
if [ ! -f "$outputfile" ]
then
    	echo "Output file does not exist , creating new file."
	cat $inputfile > $outputfile
else 
	echo "Output file already exist, hence just doing a copy."
	cp $inputfile $outputfile
fi

while read line || [[ -n $line ]]; do
        key=`echo $line | cut -s -d'=' -f1`
        if [ $key == "title" ]
	then
		titlevalue=`echo $line | cut -d'=' -f2-`
        elif [ $key == "environment" ]
	then
		envvalue=`echo $line | cut -d'=' -f2-`
	fi
done < $propfile

sed -i 's/\[\[title\]\]/'"$titlevalue"'/'  $outputfile
sed -i 's/\[\[environment\]\]/'"$envvalue"'/' $outputfile

echo -e "\nNow the input file is remain unchanged\n"
cat $inputfile

echo -e "\nBut, the output file has changed :\n"
cat $outputfile

echo "========== EXIT =============="
