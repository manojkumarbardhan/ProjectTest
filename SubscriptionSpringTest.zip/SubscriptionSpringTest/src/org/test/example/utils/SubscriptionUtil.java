package org.test.example.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.test.example.constants.SubscriptionConstants;

/**
 * 
 * @author manoj
 * 
 */
@Component
public class SubscriptionUtil {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SubscriptionUtil.class);

	public String truncate(String orderDetails, int characterAllowed) {

		LOGGER.info("OrderDetails before changes :: {}", orderDetails);
		LOGGER.info("OrderDetails Length :: {}", orderDetails.length());
		LOGGER.info("Total number of characters allowed :: {}",
				characterAllowed);

		StringBuffer finalStringBf = new StringBuffer();
		if ((orderDetails.length() >= (characterAllowed + SubscriptionConstants.TRUNCATED
				.length()))
				&& characterAllowed > SubscriptionConstants.TRUNCATED.length()) {
			int totalLength = orderDetails.length();
			int operationIndex = characterAllowed
					- SubscriptionConstants.TRUNCATED.length();
			LOGGER.info("Operational index is:: {}", operationIndex);

			int indexStart = 0;
			int calculateIndex = operationIndex / 2;
			if (operationIndex % 2 == 0) {
				LOGGER.info("Even");
				indexStart = calculateIndex;
			} else {
				LOGGER.info("Odd");
				indexStart = calculateIndex + 1;
			}

			LOGGER.info("Index to Start ::{}", indexStart);
			finalStringBf.append(orderDetails.substring(0, indexStart));
			finalStringBf.append(SubscriptionConstants.TRUNCATED);
			finalStringBf.append(orderDetails.substring(totalLength
					- calculateIndex, totalLength));
			;
			LOGGER.info("Result String is ::{}", finalStringBf);
			LOGGER.info("Result String Length is ::{}", finalStringBf.length());
			LOGGER.info("OrderDetails after operation ::{}", orderDetails);
			return finalStringBf.toString();
		} else {
			LOGGER.info(
					"Note - the truncate will not work for the given allowed length ::{}",
					characterAllowed);
			LOGGER.info(
					"The Source string is unchanged and returning same ::{}",
					orderDetails);
			finalStringBf.append(finalStringBf);
			return finalStringBf.toString();
		}

	}
}
