package org.test.example.constants;

/**
 * 
 * @author manoj
 * 
 */
public class SubscriptionConstants {
	public static final String TRUNCATED = "...(truncated)...";
}
