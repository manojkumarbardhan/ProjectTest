package org.test.example.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.test.example.utils.SubscriptionUtil;

/**
 * 
 * @author manoj
 * 
 */
@Component
public class SubscriptionController {

	@Autowired
	private SubscriptionUtil subscriptionUtil;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SubscriptionController.class);

	@RequestMapping(value = "/subscribe", method = RequestMethod.GET)
	public String subscribe(HttpServletRequest request) {
		String orderDetails = getOrderDetails(request);
		String truncatedOrderDetails = subscriptionUtil.truncate(orderDetails,
				250);
		LOGGER.info("Truncated Order {}", truncatedOrderDetails);
		return truncatedOrderDetails;
	}

	/**
	 * 
	 * @param request
	 * @return order details as form of String.
	 */
	private String getOrderDetails(HttpServletRequest request) {
		StringBuffer orderDetailsBf = null;
		if (null != request) {
			// Assuming that the order detail will be inside param.
			orderDetailsBf = new StringBuffer(
					request.getParameter("orderDetails"));
		}
		return orderDetailsBf.toString();
	}
}
