I have used below jars , these versions were available in my local dev machine.

javax.servlet-api-3.0.1.jar
slf4j-api-1.7.7.jar
spring-beans-4.1.7.RELEASE.jar
spring-core-4.1.7-RELEASE.jar
spring-context-4.1.7.RELEASE.jar
spring-integration-core-2.1.1.RELEASE.jar
spring-web-3.0.5.RELEASE.jar
spring-webmvc-3.0.5.RELEASE.jar
spring-ws-core-2.0.4.RELEASE.jar
spring-ws-support-2.0.2.RELEASE.jar

Assumptions :-

We can configure this SubscriptionSpringTest project with Maven, provided the pom.xml and super pom configuration as per organization level.
Assuming the logging log4j.xml & log4j.dtd has been configured, hence I have used the logging. I am assuming that all configuration related to the project i.e. context, dispatcher-servlet or any other xml file are already configured.I have only provided the skeleton with business logic.This project is not deployable now.


Execution Flow - When the request will hit the controller via the defined /path , then the flow will execute the respective method to meet our bussiness logic. For our project finally the truncate() method will execute for get our required result.




